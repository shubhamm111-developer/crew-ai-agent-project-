import os
from dotenv import load_dotenv
load_dotenv()

from crewai import Crew, Task
from agents.tech_support_agent import tech_support_agent
from agents.billing_agent import billing_agent
from agents.product_info_agent import product_info_agent
from agents.escalation_manager_agent import escalation_manager_agent
from config import OPENAI_API_KEY
import os

# Set API key in environment
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

# Tasks — descriptions and outputs are plain strings (not dicts)
task1 = Task(
    description="Assist the customer in resolving a login issue with step-by-step guidance.",
    expected_output="Step-by-step guide to resolve the login issue.",
    agent=tech_support_agent
)

task2 = Task(
    description="Investigate why the customer was charged twice last month and provide a refund if needed.",
    expected_output="Explanation and resolution of the double charge issue.",
    agent=billing_agent
)

task3 = Task(
    description="Provide a detailed explanation of the Premium Plan features and compare it to other plans.",
    expected_output="Feature comparison and benefits of Premium Plan.",
    agent=product_info_agent
)

task4 = Task(
    description="Handle an escalated case from an angry customer whose issue wasn't resolved properly. Apologize and offer a final solution.",
    expected_output="Formal apology and actionable solution.",
    agent=escalation_manager
)

# Build the crew
crew = Crew(
    agents=[tech_support_agent, billing_agent, product_info_agent, escalation_manager],
    tasks=[task1, task2, task3, task4],
    verbose=True
)

# Run the crew
if __name__ == "__main__":
    print("🚀 Starting the support crew...\n")
    result = crew.kickoff()
    print("\n✅ Final Result:\n")
    print(result)
