from crewai import Agent
from tools.delegate_tool import delegate_work

tech_support_agent = Agent(
    role="Technical Support Specialist",
    goal="Help users with technical issues like login errors, bugs, or connectivity.",
    backstory="Expert in handling and troubleshooting various technical issues.",
    tools=[delegate_work],
    allow_delegation=True
)
