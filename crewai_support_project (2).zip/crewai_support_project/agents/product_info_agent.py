from crewai import Agent
from tools.delegate_tool import delegate_work

product_info_agent = Agent(
    role="Product Information Assistant",
    goal="Explain product plans, pricing, and features to users.",
    backstory="Knows all product details and can explain them clearly to customers.",
    tools=[delegate_work],
    allow_delegation=True
)
