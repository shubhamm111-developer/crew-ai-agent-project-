from crewai import Agent
from tools.delegate_tool import delegate_work

escalation_manager = Agent(
    role="Escalation Manager",
    goal="Handle complaints and provide final resolutions for unresolved issues.",
    backstory="Handles critical issues and ensures customer satisfaction at all costs.",
    tools=[delegate_work],
    allow_delegation=True
)
