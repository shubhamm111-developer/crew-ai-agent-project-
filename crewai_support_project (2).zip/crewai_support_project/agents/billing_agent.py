from crewai import Agent
from tools.delegate_tool import delegate_work

billing_agent = Agent(
    role="Billing Specialist",
    goal="Resolve customer billing and payment issues.",
    backstory="Expert in payment gateways, refund policies, and billing systems.",
    tools=[delegate_work],
    allow_delegation=True
)
