from langchain.tools import Tool

def delegate_work(task: str, context: str) -> str:
    """Delegate a task with context to another agent."""
    return f"✅ Task delegated:\n\n📋 Task: {task}\n🧠 Context: {context}"

delegate_tool = Tool(
    name="Delegate Work",
    func=delegate_work,
    description="Use this tool to delegate tasks with context to another agent"
)
